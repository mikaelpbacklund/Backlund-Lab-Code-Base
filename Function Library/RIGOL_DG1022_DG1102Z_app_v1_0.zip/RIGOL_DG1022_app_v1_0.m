classdef RIGOL_DG1022_app_v1_0 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                        matlab.ui.Figure
        Output1Button                   matlab.ui.control.Button
        Output2Button                   matlab.ui.control.Button
        FreqEditFieldLabel              matlab.ui.control.Label
        FreqEditField                   matlab.ui.control.NumericEditField
        AmplEditFieldLabel              matlab.ui.control.Label
        AmplEditField                   matlab.ui.control.NumericEditField
        OffsetEditFieldLabel            matlab.ui.control.Label
        OffsetEditField                 matlab.ui.control.NumericEditField
        PhaseEditFieldLabel             matlab.ui.control.Label
        PhaseEditField                  matlab.ui.control.NumericEditField
        FreqEditField_2Label            matlab.ui.control.Label
        FreqEditField_2                 matlab.ui.control.NumericEditField
        AmplEditField_2Label            matlab.ui.control.Label
        AmplEditField_2                 matlab.ui.control.NumericEditField
        OffsetEditField_2Label          matlab.ui.control.Label
        OffsetEditField_2               matlab.ui.control.NumericEditField
        PhaseEditField_2Label           matlab.ui.control.Label
        PhaseEditField_2                matlab.ui.control.NumericEditField
        SineButton                      matlab.ui.control.Button
        SquareButton                    matlab.ui.control.Button
        CH1CH2Button                    matlab.ui.control.Button
        CH1Label                        matlab.ui.control.Label
        CH2Label                        matlab.ui.control.Label
        SendButton                      matlab.ui.control.Button
        RampButton                      matlab.ui.control.Button
        DutyEditFieldLabel              matlab.ui.control.Label
        DutyEditField                   matlab.ui.control.NumericEditField
        DutyEditField_2Label            matlab.ui.control.Label
        DutyEditField_2                 matlab.ui.control.NumericEditField
        VISAcodeEditFieldLabel          matlab.ui.control.Label
        VISAcodeEditField               matlab.ui.control.EditField
        PulseButton                     matlab.ui.control.Button
        HzLabel                         matlab.ui.control.Label
        HzLabel_2                       matlab.ui.control.Label
        VppVLabel                       matlab.ui.control.Label
        VppVLabel_2                     matlab.ui.control.Label
        VLabel                          matlab.ui.control.Label
        VLabel_2                        matlab.ui.control.Label
        degLabel                        matlab.ui.control.Label
        degLabel_2                      matlab.ui.control.Label
        Label                           matlab.ui.control.Label
        Label_2                         matlab.ui.control.Label
        Label_3                         matlab.ui.control.Label
        Label_4                         matlab.ui.control.Label
        NoiseButton                     matlab.ui.control.Button
        DCButton                        matlab.ui.control.Button
        ControlPanelforRigolDS1022SignalGeneratorLabel  matlab.ui.control.Label
        authorDominikSierociukWUTLabel  matlab.ui.control.Label
    end

    
    properties (Access = private)
        but1 int8=0 % Description
        but2 int8=0
        chan int8=1
        typ_ch1 int8=1
        typ_ch2 int8=1
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: Output1Button
        function Output1ButtonPushed(app, event)
           if app.but1==0 
            v = visa('ni',app.VISAcodeEditField.Value);
            fopen(v);
            fprintf(v,'OUTP ON');
            fclose(v);
            app.Output1Button.BackgroundColor='g';
            app.but1=1; 
           else
             v = visa('ni',app.VISAcodeEditField.Value);
            fopen(v);
            fprintf(v,'OUTP OFF');
            fclose(v);
            app.Output1Button.BackgroundColor=[0.96,0.96,0.96];  
            app.but1=0; 
           end
           
        end

        % Button pushed function: Output2Button
        function Output2ButtonPushed(app, event)
        if app.but2==0 
            v = visa('ni',app.VISAcodeEditField.Value);
            fopen(v);
            fprintf(v,'OUTP:CH2 ON');
            fclose(v);
            app.Output2Button.BackgroundColor='g';
            app.but2=1; 
           else
             v = visa('ni',app.VISAcodeEditField.Value);
            fopen(v);
            fprintf(v,'OUTP:CH2 OFF');
            fclose(v);
            app.Output2Button.BackgroundColor=[0.96,0.96,0.96];  
            app.but2=0; 
           end
        end

        % Button pushed function: CH1CH2Button
        function CH1CH2ButtonPushed(app, event)
                app.SineButton.BackgroundColor=[0.96,0.96,0.96];
                app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
                app.RampButton.BackgroundColor=[0.96,0.96,0.96]; 
                app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
                app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
                app.DCButton.BackgroundColor=[0.96,0.96,0.96];
                app.FreqEditField.Editable='off';
                app.AmplEditField.Editable='off';
                app.OffsetEditField.Editable='off';
                app.PhaseEditField.Editable='off';
                app.DutyEditField.Editable='off';
                app.FreqEditField_2.Editable='off';
                app.AmplEditField_2.Editable='off';
                app.OffsetEditField_2.Editable='off';
                app.PhaseEditField_2.Editable='off';
                app.DutyEditField_2.Editable='off';
                
                
            if app.chan==1
% Channel 2
                app.CH1Label.BackgroundColor=[0.96,0.96,0.96];
                app.CH2Label.BackgroundColor='g';
                app.FreqEditField_2.Editable='on';
                app.AmplEditField_2.Editable='on';
                app.OffsetEditField_2.Editable='on';
                app.PhaseEditField_2.Editable='on';
                if app.typ_ch2==1
                    app.SineButton.BackgroundColor='g';
                    app.DutyEditField_2Label.Text='Duty';
                elseif app.typ_ch2==2
                    app.SquareButton.BackgroundColor='g';
                    app.DutyEditField_2.Editable='on';
                    app.DutyEditField_2Label.Text='Duty';
                elseif app.typ_ch2==3
                    app.RampButton.BackgroundColor='g'; 
                    app.DutyEditField_2.Editable='on';
                    app.DutyEditField_2Label.Text='Symmetry';
                elseif app.typ_ch2==4
                    app.PulseButton.BackgroundColor='g'; 
                    app.DutyEditField_2.Editable='on';
                    app.DutyEditField_2Label.Text='Duty';
                elseif app.typ_ch2==5
                    app.NoiseButton.BackgroundColor='g'; 
                    app.DutyEditField_2Label.Text='Duty';
                    app.FreqEditField_2.Editable='off';
                    app.PhaseEditField_2.Editable='off';
                elseif app.typ_ch2==6
                    app.DCButton.BackgroundColor='g'; 
                    app.DutyEditField_2Label.Text='Duty';
                    app.FreqEditField_2.Editable='off';
                    app.PhaseEditField_2.Editable='off';
                    app.AmplEditField_2.Editable='off';
                end
                
                app.chan=2;
            else
% Channel 1
                app.CH2Label.BackgroundColor=[0.96,0.96,0.96];
                app.CH1Label.BackgroundColor='g';
                app.FreqEditField.Editable='on';
                app.AmplEditField.Editable='on';
                app.OffsetEditField.Editable='on';
                app.PhaseEditField.Editable='on';
                if app.typ_ch1==1
                    app.SineButton.BackgroundColor='g';
                    app.DutyEditFieldLabel.Text='Duty';
                elseif app.typ_ch1==2
                    app.SquareButton.BackgroundColor='g';
                    app.DutyEditField.Editable='on';
                    app.DutyEditFieldLabel.Text='Duty';
                elseif app.typ_ch1==3
                    app.RampButton.BackgroundColor='g'; 
                    app.DutyEditField.Editable='on';
                    app.DutyEditFieldLabel.Text='Symmetry';
                elseif app.typ_ch1==4
                    app.PulseButton.BackgroundColor='g'; 
                    app.DutyEditFieldLabel.Text='Duty';
                    app.DutyEditField.Editable='on';
                elseif app.typ_ch1==5
                    app.NoiseButton.BackgroundColor='g'; 
                    app.DutyEditFieldLabel.Text='Duty';
                    app.FreqEditField.Editable='off';
                    app.PhaseEditField.Editable='off';
                elseif app.typ_ch1==6
                    app.DCButton.BackgroundColor='g'; 
                    app.DutyEditFieldLabel.Text='Duty';
                    app.FreqEditField.Editable='off';
                    app.PhaseEditField.Editable='off';
                    app.AmplEditField.Editable='off';
                end
                
                app.chan=1;
            end
        end

        % Button pushed function: SendButton
        function SendButtonPushed(app, event)
        
            
                       
            
            app.Label_3.Text='';
            if app.typ_ch1==1 && app.chan==1
            s=sprintf('APPL:SIN %f,%f,%f\n',app.FreqEditField.Value,app.AmplEditField.Value,app.OffsetEditField.Value);
            s2=sprintf('PHAS %f\n',app.PhaseEditField.Value);
            s3='';
            elseif  app.typ_ch1==2 && app.chan==1
             s=sprintf('APPL:SQU %f,%f,%f,%f,%f\n',app.FreqEditField.Value,app.AmplEditField.Value,app.OffsetEditField.Value);    
             s2=sprintf('PHAS %f\n',app.PhaseEditField.Value);
             
            if app.DutyEditField.Value==0
                 app.Label_3.Text='Duty can not be equal to 0';
                 s3='';
             else
                s3=sprintf('FUNC:SQU:DCYC %f\n',app.DutyEditField.Value);
            end
            elseif  app.typ_ch1==3 && app.chan==1
             s=sprintf('APPL:RAMP %f,%f,%f,%f,%f\n',app.FreqEditField.Value,app.AmplEditField.Value,app.OffsetEditField.Value);    
             s2=sprintf('PHAS %f\n',app.PhaseEditField.Value);
             s3=sprintf('FUNC:RAMP:SYMM %f\n',app.DutyEditField.Value);
            elseif  app.typ_ch1==4 && app.chan==1
             s=sprintf('APPL:PULS %f,%f,%f,%f,%f\n',app.FreqEditField.Value,app.AmplEditField.Value,app.OffsetEditField.Value);    
             s2=sprintf('PHAS %f\n',app.PhaseEditField.Value);
            if app.DutyEditField.Value==0
                 app.Label_3.Text='Duty can not be equal to 0';
                 s3='';
             else
                 s3=sprintf('PULSE:DCYC %f\n',app.DutyEditField.Value);
             end
             elseif  app.typ_ch1==5 && app.chan==1
             s=sprintf('APPL:NOIS DEF,%f,%f',app.AmplEditField.Value,app.OffsetEditField.Value);    
             s2='';
             s3='';
             elseif  app.typ_ch1==6 && app.chan==1
             s=sprintf('APPL:DC DEF,DEF,%f',app.OffsetEditField.Value);    
             s2='';
             s3='';
            end
            
            if app.typ_ch2==1 && app.chan==2
            s=sprintf('APPL:SIN:CH2 %f,%f,%f\n',app.FreqEditField_2.Value,app.AmplEditField_2.Value,app.OffsetEditField_2.Value);
            s2=sprintf('PHAS:CH2 %f\n',app.PhaseEditField_2.Value);
            s3='';
            elseif  app.typ_ch2==2 && app.chan==2
            s=sprintf('APPL:SQU:CH2 %f,%f,%f,%f,%f\n',app.FreqEditField_2.Value,app.AmplEditField_2.Value,app.OffsetEditField_2.Value);    
             s2=sprintf('PHAS:CH2 %f\n',app.PhaseEditField_2.Value);
             
               if app.DutyEditField.Value==0
                 app.Label_3.Text='Duty can not be equal to 0';
                 s3='';
             else
              s3=sprintf('FUNC:SQU:DCYC:CH2 %f\n',app.DutyEditField_2.Value);
               end
            elseif  app.typ_ch2==3 && app.chan==2
              s=sprintf('APPL:RAMP:CH2 %f,%f,%f,%f,%f\n',app.FreqEditField_2.Value,app.AmplEditField_2.Value,app.OffsetEditField_2.Value);    
             s2=sprintf('PHAS:CH2 %f\n',app.PhaseEditField_2.Value);
             s3=sprintf('FUNC:RAMP:SYMM:CH2 %f\n',app.DutyEditField_2.Value);
            elseif  app.typ_ch2==4 && app.chan==2
            s=sprintf('APPL:PULS:CH2 %f,%f,%f,%f,%f\n',app.FreqEditField_2.Value,app.AmplEditField_2.Value,app.OffsetEditField_2.Value);    
             s2=sprintf('PHAS:CH2 %f\n',app.PhaseEditField_2.Value);
             
               if app.DutyEditField.Value==0
                 app.Label_3.Text='Duty can not be equal to 0';
                 s3='';
               else
                s3=sprintf('PULSE:DCYC:CH2 %f\n',app.DutyEditField_2.Value);
               end
             elseif  app.typ_ch2==5 && app.chan==2
                 s=sprintf('APPL:NOIS:CH2 DEF,%f,%f',app.AmplEditField_2.Value,app.OffsetEditField_2.Value);   
                 s2='';
                 s3='';
             elseif  app.typ_ch2==6 && app.chan==2
               s=sprintf('APPL:DC:CH2 DEF,DEF,%f',app.OffsetEditField_2.Value);    
               s2='';
               s3='';            
            end
            v = visa('ni',app.VISAcodeEditField.Value);
            fopen(v); 
            fprintf(v,'VOLT:UNIT VPP\n');
            pause(0.02);
            fprintf(v,'VOLT:UNIT:CH2 VPP\n');
        pause(0.02);
           fprintf(v,s);
           pause(0.02);
            fprintf(v,s2);
            pause(0.02);
            fprintf(v,s3);
            fclose(v);
            
        end

        % Button pushed function: SineButton
        function SineButtonPushed(app, event)
            if app.chan==1
            app.typ_ch1=1;
            app.DutyEditField.Editable='off';
            app.DutyEditFieldLabel.Text='Duty';
            app.FreqEditField.Editable='on';
            app.PhaseEditField.Editable='on';
            app.AmplEditField.Editable='on';
            else
             app.typ_ch2=1;
              app.DutyEditField_2.Editable='off';
              app.DutyEditField_2Label.Text='Duty';
              app.FreqEditField_2.Editable='on';
              app.PhaseEditField_2.Editable='on';
              app.AmplEditField_2.Editable='on';
            end
            app.SineButton.BackgroundColor='g';
            app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
            app.RampButton.BackgroundColor=[0.96,0.96,0.96]; 
            app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
            app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
            app.DCButton.BackgroundColor=[0.96,0.96,0.96];
        end

        % Button pushed function: SquareButton
        function SquareButtonPushed(app, event)
            if app.chan==1
            app.typ_ch1=2;
             app.DutyEditField.Editable='on';
             app.DutyEditFieldLabel.Text='Duty';
             app.FreqEditField.Editable='on';
            app.PhaseEditField.Editable='on';
            app.AmplEditField.Editable='on';
            else
             app.DutyEditField_2.Editable='on';
             app.DutyEditField_2Label.Text='Duty';
             app.FreqEditField_2.Editable='on';
             app.PhaseEditField_2.Editable='on';
             app.AmplEditField_2.Editable='on';
             app.typ_ch2=2;
            end
            app.SineButton.BackgroundColor=[0.96,0.96,0.96];
            app.SquareButton.BackgroundColor='g';
            app.RampButton.BackgroundColor=[0.96,0.96,0.96]; 
            app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
            app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
            app.DCButton.BackgroundColor=[0.96,0.96,0.96];
        end

        % Button pushed function: RampButton
        function RampButtonPushed(app, event)
            if app.chan==1
             app.typ_ch1=3;
             app.DutyEditField.Editable='on';
             app.DutyEditFieldLabel.Text='Symmetry';
             app.FreqEditField.Editable='on';
             app.PhaseEditField.Editable='on';
             app.AmplEditField.Editable='on';
            else
             app.typ_ch2=3;
             app.DutyEditField_2.Editable='on';
             app.DutyEditField_2Label.Text='Symmetry';
             app.FreqEditField_2.Editable='on';
             app.PhaseEditField_2.Editable='on';
             app.AmplEditField_2.Editable='on';
            end
            app.SineButton.BackgroundColor=[0.96,0.96,0.96];
            app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
            app.RampButton.BackgroundColor='g'; 
            app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
            app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
            app.DCButton.BackgroundColor=[0.96,0.96,0.96];
        end

        % Button pushed function: PulseButton
        function PulseButtonPushed(app, event)
             if app.chan==1
               app.typ_ch1=4;
                app.DutyEditField.Editable='on';
                app.DutyEditFieldLabel.Text='Duty';
                app.FreqEditField.Editable='on';
                app.PhaseEditField.Editable='on';
                app.AmplEditField.Editable='on';
            else
              app.typ_ch2=4;
              app.DutyEditField_2.Editable='on';
              app.DutyEditField_2Label.Text='Duty';
              app.FreqEditField_2.Editable='on';
              app.PhaseEditField_2.Editable='on';
              app.AmplEditField_2.Editable='on';
            end
            app.SineButton.BackgroundColor=[0.96,0.96,0.96];
            app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
            app.RampButton.BackgroundColor=[0.96,0.96,0.96];
            app.PulseButton.BackgroundColor='g';
            app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
            app.DCButton.BackgroundColor=[0.96,0.96,0.96];
        end

        % Button pushed function: NoiseButton
        function NoiseButtonPushed(app, event)
             if app.chan==1
            app.typ_ch1=5;
            app.DutyEditField.Editable='off';
            app.DutyEditFieldLabel.Text='Duty';
            app.FreqEditField.Editable='off';
            app.PhaseEditField.Editable='off';
            app.AmplEditField.Editable='on';
            else
             app.typ_ch2=5;
              app.DutyEditField_2.Editable='off';
              app.DutyEditField_2Label.Text='Duty';
              app.FreqEditField_2.Editable='off';
              app.PhaseEditField_2.Editable='off';
              app.AmplEditField_2.Editable='on';
            end
            app.SineButton.BackgroundColor=[0.96,0.96,0.96];
            app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
            app.RampButton.BackgroundColor=[0.96,0.96,0.96]; 
            app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
            app.NoiseButton.BackgroundColor='g';
            app.DCButton.BackgroundColor=[0.96,0.96,0.96];
        end

        % Button pushed function: DCButton
        function DCButtonPushed(app, event)
             if app.chan==1
            app.typ_ch1=6;
            app.DutyEditField.Editable='off';
            app.DutyEditFieldLabel.Text='Duty';
             app.FreqEditField.Editable='off';
            app.PhaseEditField.Editable='off';
            app.AmplEditField.Editable='off';
            else
             app.typ_ch2=6;
              app.DutyEditField_2.Editable='off';
              app.DutyEditField_2Label.Text='Duty';
              app.FreqEditField_2.Editable='off';
              app.PhaseEditField_2.Editable='off';
              app.AmplEditField_2.Editable='off';
            end
            app.SineButton.BackgroundColor=[0.96,0.96,0.96];
            app.SquareButton.BackgroundColor=[0.96,0.96,0.96];
            app.RampButton.BackgroundColor=[0.96,0.96,0.96]; 
            app.PulseButton.BackgroundColor=[0.96,0.96,0.96];
            app.NoiseButton.BackgroundColor=[0.96,0.96,0.96];
            app.DCButton.BackgroundColor='g';
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 685 507];
            app.UIFigure.Name = 'MATLAB App';

            % Create Output1Button
            app.Output1Button = uibutton(app.UIFigure, 'push');
            app.Output1Button.ButtonPushedFcn = createCallbackFcn(app, @Output1ButtonPushed, true);
            app.Output1Button.Position = [312 70 93 53];
            app.Output1Button.Text = 'Output1';

            % Create Output2Button
            app.Output2Button = uibutton(app.UIFigure, 'push');
            app.Output2Button.ButtonPushedFcn = createCallbackFcn(app, @Output2ButtonPushed, true);
            app.Output2Button.Position = [484 70 100 53];
            app.Output2Button.Text = 'Output2';

            % Create FreqEditFieldLabel
            app.FreqEditFieldLabel = uilabel(app.UIFigure);
            app.FreqEditFieldLabel.HorizontalAlignment = 'right';
            app.FreqEditFieldLabel.Position = [83 414 30 22];
            app.FreqEditFieldLabel.Text = 'Freq';

            % Create FreqEditField
            app.FreqEditField = uieditfield(app.UIFigure, 'numeric');
            app.FreqEditField.Position = [128 416 100 22];
            app.FreqEditField.Value = 50;

            % Create AmplEditFieldLabel
            app.AmplEditFieldLabel = uilabel(app.UIFigure);
            app.AmplEditFieldLabel.HorizontalAlignment = 'right';
            app.AmplEditFieldLabel.Position = [80 378 33 22];
            app.AmplEditFieldLabel.Text = 'Ampl';

            % Create AmplEditField
            app.AmplEditField = uieditfield(app.UIFigure, 'numeric');
            app.AmplEditField.Position = [128 378 100 22];
            app.AmplEditField.Value = 5;

            % Create OffsetEditFieldLabel
            app.OffsetEditFieldLabel = uilabel(app.UIFigure);
            app.OffsetEditFieldLabel.HorizontalAlignment = 'right';
            app.OffsetEditFieldLabel.Position = [76 342 37 22];
            app.OffsetEditFieldLabel.Text = 'Offset';

            % Create OffsetEditField
            app.OffsetEditField = uieditfield(app.UIFigure, 'numeric');
            app.OffsetEditField.Position = [128 342 100 22];

            % Create PhaseEditFieldLabel
            app.PhaseEditFieldLabel = uilabel(app.UIFigure);
            app.PhaseEditFieldLabel.HorizontalAlignment = 'right';
            app.PhaseEditFieldLabel.Position = [73 299 40 22];
            app.PhaseEditFieldLabel.Text = 'Phase';

            % Create PhaseEditField
            app.PhaseEditField = uieditfield(app.UIFigure, 'numeric');
            app.PhaseEditField.Position = [128 299 100 22];

            % Create FreqEditField_2Label
            app.FreqEditField_2Label = uilabel(app.UIFigure);
            app.FreqEditField_2Label.HorizontalAlignment = 'right';
            app.FreqEditField_2Label.Position = [82 196 30 22];
            app.FreqEditField_2Label.Text = 'Freq';

            % Create FreqEditField_2
            app.FreqEditField_2 = uieditfield(app.UIFigure, 'numeric');
            app.FreqEditField_2.Editable = 'off';
            app.FreqEditField_2.Position = [128 196 100 22];
            app.FreqEditField_2.Value = 50;

            % Create AmplEditField_2Label
            app.AmplEditField_2Label = uilabel(app.UIFigure);
            app.AmplEditField_2Label.HorizontalAlignment = 'right';
            app.AmplEditField_2Label.Position = [80 158 33 22];
            app.AmplEditField_2Label.Text = 'Ampl';

            % Create AmplEditField_2
            app.AmplEditField_2 = uieditfield(app.UIFigure, 'numeric');
            app.AmplEditField_2.Editable = 'off';
            app.AmplEditField_2.Position = [128 158 100 22];
            app.AmplEditField_2.Value = 5;

            % Create OffsetEditField_2Label
            app.OffsetEditField_2Label = uilabel(app.UIFigure);
            app.OffsetEditField_2Label.HorizontalAlignment = 'right';
            app.OffsetEditField_2Label.Position = [76 122 37 22];
            app.OffsetEditField_2Label.Text = 'Offset';

            % Create OffsetEditField_2
            app.OffsetEditField_2 = uieditfield(app.UIFigure, 'numeric');
            app.OffsetEditField_2.Editable = 'off';
            app.OffsetEditField_2.Position = [128 122 100 22];

            % Create PhaseEditField_2Label
            app.PhaseEditField_2Label = uilabel(app.UIFigure);
            app.PhaseEditField_2Label.HorizontalAlignment = 'right';
            app.PhaseEditField_2Label.Position = [73 79 40 22];
            app.PhaseEditField_2Label.Text = 'Phase';

            % Create PhaseEditField_2
            app.PhaseEditField_2 = uieditfield(app.UIFigure, 'numeric');
            app.PhaseEditField_2.Editable = 'off';
            app.PhaseEditField_2.Position = [128 79 100 22];

            % Create SineButton
            app.SineButton = uibutton(app.UIFigure, 'push');
            app.SineButton.ButtonPushedFcn = createCallbackFcn(app, @SineButtonPushed, true);
            app.SineButton.BackgroundColor = [0 1 0];
            app.SineButton.Position = [294 414 37 26];
            app.SineButton.Text = 'Sine';

            % Create SquareButton
            app.SquareButton = uibutton(app.UIFigure, 'push');
            app.SquareButton.ButtonPushedFcn = createCallbackFcn(app, @SquareButtonPushed, true);
            app.SquareButton.Position = [348 414 57 24];
            app.SquareButton.Text = 'Square';

            % Create CH1CH2Button
            app.CH1CH2Button = uibutton(app.UIFigure, 'push');
            app.CH1CH2Button.ButtonPushedFcn = createCallbackFcn(app, @CH1CH2ButtonPushed, true);
            app.CH1CH2Button.Position = [310 271 111 28];
            app.CH1CH2Button.Text = 'CH1/CH2';

            % Create CH1Label
            app.CH1Label = uilabel(app.UIFigure);
            app.CH1Label.BackgroundColor = [0 1 0];
            app.CH1Label.Position = [27 416 30 22];
            app.CH1Label.Text = 'CH1';

            % Create CH2Label
            app.CH2Label = uilabel(app.UIFigure);
            app.CH2Label.Position = [27 196 30 22];
            app.CH2Label.Text = 'CH2';

            % Create SendButton
            app.SendButton = uibutton(app.UIFigure, 'push');
            app.SendButton.ButtonPushedFcn = createCallbackFcn(app, @SendButtonPushed, true);
            app.SendButton.Position = [447 249 137 72];
            app.SendButton.Text = 'Send';

            % Create RampButton
            app.RampButton = uibutton(app.UIFigure, 'push');
            app.RampButton.ButtonPushedFcn = createCallbackFcn(app, @RampButtonPushed, true);
            app.RampButton.Position = [421 416 47 21];
            app.RampButton.Text = 'Ramp';

            % Create DutyEditFieldLabel
            app.DutyEditFieldLabel = uilabel(app.UIFigure);
            app.DutyEditFieldLabel.HorizontalAlignment = 'right';
            app.DutyEditFieldLabel.Position = [56 261 57 22];
            app.DutyEditFieldLabel.Text = 'Duty';

            % Create DutyEditField
            app.DutyEditField = uieditfield(app.UIFigure, 'numeric');
            app.DutyEditField.Editable = 'off';
            app.DutyEditField.Position = [126 261 100 22];
            app.DutyEditField.Value = 50;

            % Create DutyEditField_2Label
            app.DutyEditField_2Label = uilabel(app.UIFigure);
            app.DutyEditField_2Label.HorizontalAlignment = 'right';
            app.DutyEditField_2Label.Position = [56 40 57 22];
            app.DutyEditField_2Label.Text = 'Duty';

            % Create DutyEditField_2
            app.DutyEditField_2 = uieditfield(app.UIFigure, 'numeric');
            app.DutyEditField_2.Editable = 'off';
            app.DutyEditField_2.Position = [128 40 100 22];
            app.DutyEditField_2.Value = 50;

            % Create VISAcodeEditFieldLabel
            app.VISAcodeEditFieldLabel = uilabel(app.UIFigure);
            app.VISAcodeEditFieldLabel.HorizontalAlignment = 'right';
            app.VISAcodeEditFieldLabel.Position = [122 452 62 22];
            app.VISAcodeEditFieldLabel.Text = 'VISA code';

            % Create VISAcodeEditField
            app.VISAcodeEditField = uieditfield(app.UIFigure, 'text');
            app.VISAcodeEditField.Position = [199 452 411 22];
            app.VISAcodeEditField.Value = 'USB1::0x1AB1::0x0642::DG1ZA?????????::INSTR';

            % Create PulseButton
            app.PulseButton = uibutton(app.UIFigure, 'push');
            app.PulseButton.ButtonPushedFcn = createCallbackFcn(app, @PulseButtonPushed, true);
            app.PulseButton.Position = [484 414 48 23];
            app.PulseButton.Text = 'Pulse';

            % Create HzLabel
            app.HzLabel = uilabel(app.UIFigure);
            app.HzLabel.Position = [237 416 18 22];
            app.HzLabel.Text = 'Hz';

            % Create HzLabel_2
            app.HzLabel_2 = uilabel(app.UIFigure);
            app.HzLabel_2.Position = [237 196 18 22];
            app.HzLabel_2.Text = 'Hz';

            % Create VppVLabel
            app.VppVLabel = uilabel(app.UIFigure);
            app.VppVLabel.Position = [237 378 45 22];
            app.VppVLabel.Text = 'Vpp [V]';

            % Create VppVLabel_2
            app.VppVLabel_2 = uilabel(app.UIFigure);
            app.VppVLabel_2.Position = [237 158 45 22];
            app.VppVLabel_2.Text = 'Vpp [V]';

            % Create VLabel
            app.VLabel = uilabel(app.UIFigure);
            app.VLabel.Position = [237 342 25 22];
            app.VLabel.Text = 'V';

            % Create VLabel_2
            app.VLabel_2 = uilabel(app.UIFigure);
            app.VLabel_2.Position = [237 122 25 22];
            app.VLabel_2.Text = 'V';

            % Create degLabel
            app.degLabel = uilabel(app.UIFigure);
            app.degLabel.Position = [237 299 26 22];
            app.degLabel.Text = 'deg';

            % Create degLabel_2
            app.degLabel_2 = uilabel(app.UIFigure);
            app.degLabel_2.Position = [237 79 26 22];
            app.degLabel_2.Text = 'deg';

            % Create Label
            app.Label = uilabel(app.UIFigure);
            app.Label.Position = [237 261 25 22];
            app.Label.Text = '%';

            % Create Label_2
            app.Label_2 = uilabel(app.UIFigure);
            app.Label_2.Position = [233 40 25 22];
            app.Label_2.Text = '%';

            % Create Label_3
            app.Label_3 = uilabel(app.UIFigure);
            app.Label_3.Position = [90 228 175 22];
            app.Label_3.Text = '';

            % Create Label_4
            app.Label_4 = uilabel(app.UIFigure);
            app.Label_4.Position = [75 28 175 22];
            app.Label_4.Text = '';

            % Create NoiseButton
            app.NoiseButton = uibutton(app.UIFigure, 'push');
            app.NoiseButton.ButtonPushedFcn = createCallbackFcn(app, @NoiseButtonPushed, true);
            app.NoiseButton.Position = [548 414 53 23];
            app.NoiseButton.Text = 'Noise';

            % Create DCButton
            app.DCButton = uibutton(app.UIFigure, 'push');
            app.DCButton.ButtonPushedFcn = createCallbackFcn(app, @DCButtonPushed, true);
            app.DCButton.Position = [617 413 45 24];
            app.DCButton.Text = 'DC';

            % Create ControlPanelforRigolDS1022SignalGeneratorLabel
            app.ControlPanelforRigolDS1022SignalGeneratorLabel = uilabel(app.UIFigure);
            app.ControlPanelforRigolDS1022SignalGeneratorLabel.FontSize = 16;
            app.ControlPanelforRigolDS1022SignalGeneratorLabel.Position = [187 486 359 22];
            app.ControlPanelforRigolDS1022SignalGeneratorLabel.Text = 'Control Panel for Rigol DS1022 Signal Generator';

            % Create authorDominikSierociukWUTLabel
            app.authorDominikSierociukWUTLabel = uilabel(app.UIFigure);
            app.authorDominikSierociukWUTLabel.Position = [489 7 173 22];
            app.authorDominikSierociukWUTLabel.Text = 'author: Dominik Sierociuk WUT';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = RIGOL_DG1022_app_v1_0

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end